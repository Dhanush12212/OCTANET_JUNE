
//Align the checked items to the bottom
function toggleLineThrough(checkbox) {
    const todoContainer = document.getElementById('todo-container');
    const todoDiv = checkbox.parentElement;  
    todoContainer.appendChild(todoDiv);  
}

//Reset the checkbox
function resetTodos() {
    const todoContainer = document.getElementById('todo-container');
    const todos = todoContainer.children;
    
    for (const todo of todos) {
        const checkbox = todo.querySelector('.todo-check'); 
        checkbox.checked = false;  
    }
}

//Saved message
function save() {
    const modal = document.getElementById('custom-alert-modal');
    const message = document.getElementById('custom-alert-message');
    message.textContent = 'Your list has been saved!';
    modal.style.display = 'block';
}

//Close the message
function closeModal() {
    const modal = document.getElementById('custom-alert-modal');
    modal.style.display = 'none';
}
